﻿using UnityEngine;
using System.Collections;

public class GroundScript : MonoBehaviour {

	public PieceHandler ph;

	// Use this for initialization
	void Start () {
		ph = GameObject.Find("TurnManager").GetComponent<PieceHandler>();
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnMouseDown()
	{
		if (ph.GetHasSelectedPiece())
		{
			ph.GetSelectedPiece().transform.position = this.transform.position + Vector3.up;

		}
	}
}
