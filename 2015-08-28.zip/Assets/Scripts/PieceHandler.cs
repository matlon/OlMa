﻿using UnityEngine;
using System.Collections;

public class PieceHandler : MonoBehaviour {

	private bool hasSelectedPiece;
	private PieceBehaviour currentMarkedPiece;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void SetSelectedPiece(PieceBehaviour p)
	{
		currentMarkedPiece = p;
		hasSelectedPiece = true;
	}

	public void ClearSelectedPiece()
	{
		hasSelectedPiece = false;
	}

	public bool GetHasSelectedPiece()
	{
		return hasSelectedPiece;
	}

	public PieceBehaviour GetSelectedPiece()
	{
		return currentMarkedPiece;
	}
}
