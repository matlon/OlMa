﻿using UnityEngine;
using System.Collections;

public class CreateBoard : MonoBehaviour {

	private const int WATER = 0, GROUNDCUBE = 1;

	public GameObject WaterPrefab;
	public GameObject GroundCubePrefab;

	private int[,] blockMatrix;
	// Use this for initialization
	void Start () {
		blockMatrix = new int[,]
		{
			{1,1,1,1,1,1,1,1},
			{1,1,1,0,0,1,1,1},
			{1,1,1,0,0,1,1,1},
			{1,1,1,1,1,1,1,1},
			{1,1,1,1,1,1,1,1},
			{1,1,1,0,0,1,1,1},
			{1,1,1,0,0,1,1,1},
			{1,1,1,1,1,1,1,1}
		};

		CreateGround(blockMatrix);
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void CreateGround(int[,] m)
	{
		for (int i = 0; i <= m.GetUpperBound(0); i++)
		{
			for (int j = 0; j <= m.GetUpperBound(1); j++)
			{
				CreateAtLocation(blockMatrix[i, j], i, j);
			}
		}
	}

	void CreateAtLocation(int groundType, int posX, int posZ)
	{
		if (groundType == WATER)
		{
			Instantiate(WaterPrefab, new Vector3(posX, 0, posZ), Quaternion.identity);
		}
		else if (groundType == GROUNDCUBE)
		{
			Instantiate(GroundCubePrefab, new Vector3(posX, 0, posZ), Quaternion.identity);
		}
	}
}
