﻿using UnityEngine;
using System.Collections;

public class PieceBehaviour : MonoBehaviour {
	
	public bool isSelected;
	protected PieceHandler ph;
	protected MeshRenderer mr;

	public Color selectColor = Color.red;
	// Use this for initialization
	void Start () {
		mr = GetComponent<MeshRenderer>();
		ph = GameObject.Find("TurnManager").GetComponent<PieceHandler>();
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnMouseDown () 
	{
		if (!isSelected) 	// Select this Piece
		{
			ph.SetSelectedPiece(this);
			mr.material.color = selectColor;
			isSelected = true;
		} 
		else 				// Deselect this Piece 
		{
			ph.ClearSelectedPiece();
			mr.material.color = Color.white;
			isSelected = false;
		}
	}
}
